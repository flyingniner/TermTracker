package com.termtacker;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface StatusDao
{
    @Insert
    long insertStatus(Status status);

    @Query("SELECT * FROM STATUS WHERE STATUS_ID = :statusId")
    Status getStatusById(int statusId);

    @Query("SELECT STATUS_NAME FROM STATUS WHERE STATUS_ID = :statusId")
    String getStatusNameById(int statusId);

    @Query("SELECT * FROM STATUS")
    List<Status> getStatusList();
}