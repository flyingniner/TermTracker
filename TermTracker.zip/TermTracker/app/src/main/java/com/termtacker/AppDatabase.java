package com.termtacker;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;


@Database(entities = {
        Assessment.class, Course.class,
        CourseNote.class, Mentor.class,
        Status.class, Term.class},
        version = 1)
@TypeConverters(Converters.class)
public abstract class AppDatabase extends RoomDatabase
{
    private static AppDatabase INSTANCE;
    private static final String DB_NAME = "TERM_TRACKER.DB";

    public abstract AssessmentDao assessmentDao();
    public abstract CourseDao courseDao();
    public abstract CourseNoteDao noteDao();
    public abstract MentorDao mentorDao();
    public abstract StatusDao statusDao();
    public abstract TermDao termDao();




    public static AppDatabase getInstance(final Context context)
    {
        if (INSTANCE == null)
        {
            INSTANCE = buildDatabaseInstance(context);
        }
        return INSTANCE;
    }

    private static AppDatabase buildDatabaseInstance(Context context)
    {
        AppDatabase db = Room.databaseBuilder(context,AppDatabase.class,DB_NAME).allowMainThreadQueries().build();
        return db;

        //Room.databaseBuilder(context,TermDb.class,DB_NAME).allowMainThreadQueries().build();
    }
}
