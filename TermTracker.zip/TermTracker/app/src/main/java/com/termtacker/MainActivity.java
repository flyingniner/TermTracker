package com.termtacker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppDatabase appDb = AppDatabase.getInstance(getApplicationContext());

        Button btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener((v) -> {
                    int id = v.getId();
                    Intent intent;

                    Term t = new Term();
                    t.setTermId(1);
                    long val = appDb.termDao().insertTerm(t);

                    btn.setText(Long.toString(val));
                });





    }
}
