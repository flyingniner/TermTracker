package com.termtacker;

import java.time.LocalDate;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

@Entity(tableName = "TERMS", foreignKeys = @ForeignKey(
        entity = Status.class,
        parentColumns = "STATUS_ID",
        childColumns = "FK_STATUS"))
public class Term
{
    @PrimaryKey
    @ColumnInfo(name = "TERM_ID")
    private int termId;

    @ColumnInfo(name="TERM_START_DATE")
    @TypeConverters(Converters.class)
    private LocalDate startDate;

    @ColumnInfo(name="TERM_END_DATE")
    @TypeConverters(Converters.class)
    private LocalDate endDate;

    @ColumnInfo(name="TERM_NAME")
    private String title;

    @ColumnInfo(name="FK_STATUS", index = true)
    private int statusId;

//region getters and setters

    public int getTermId()
    {
        return termId;
    }

    public void setTermId(int termId)
    {
        this.termId = termId;
    }

    public LocalDate getStartDate()
    {
        return startDate;
    }

    public void setStartDate(LocalDate startDate)
    {
        this.startDate = startDate;
    }

    public LocalDate getEndDate()
    {
        return endDate;
    }

    public void setEndDate(LocalDate endDate)
    {
        this.endDate = endDate;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public int getStatusId()
    {
        return statusId;
    }

    public void setStatusId(int statusId)
    {
        this.statusId = statusId;
    }

//endregion

}
