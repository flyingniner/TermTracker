package com.termtacker;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface CourseNoteDao
{
    @Insert()
    long insertNote(CourseNote note);

    @Update()
    int updateNote(CourseNote... note);

    @Query("SELECT * FROM NOTES WHERE FK_COURSE_ID = :courseId")
    List<CourseNote> getCourseNotesByCourseId(int courseId);

    @Delete()
    int deleteNote(CourseNote... notes);
}
