package com.termtacker;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "STATUS")
public class Status
{
    @PrimaryKey
    @ColumnInfo(name = "STATUS_ID")
    private int statusId;

    @ColumnInfo(name = "STATUS_NAME")
    private String statusName;

//region getters and setters

    public int getStatusId()
    {
        return statusId;
    }

    public void setStatusId(int statusId)
    {
        this.statusId = statusId;
    }

    public String getStatusName()
    {
        return statusName;
    }

    public void setStatusName(String statusName)
    {
        this.statusName = statusName;
    }

//endregion

}
