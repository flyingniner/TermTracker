package com.termtacker;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface MentorDao
{
    @Insert
    long insertMentor(Mentor mentor);

    @Update
    int updateMentor(Mentor mentor);

    @Query("SELECT MENTOR_ID, MENTOR_NAME, MENTOR_PHONE, MENTOR_EMAIL FROM MENTORS, " +
            "COURSES WHERE MENTOR_ID = FK_MENTOR_ID " +
            "AND COURSE_ID = :courseId")
    Mentor getMentorByCourseId(int courseId);
}
